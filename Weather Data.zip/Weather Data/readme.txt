README 

City Names:
CLT -> Charlotte, North Carolina
CQT -> Los Angeles, California
IND -> Indianapolis, Indiana
JAX -> Jacksonville, Florida
MDW -> Chicago, Illinois
PHL -> Philadelphia, Pennsylvania
PHX -> Pheonix, Arizona
KHOU -> Houston, Texas 
KNYC -> New York, New York
KSEA -> Seattle, Washington


Cities-gps.csv contains the GPS coordinates for each city. 